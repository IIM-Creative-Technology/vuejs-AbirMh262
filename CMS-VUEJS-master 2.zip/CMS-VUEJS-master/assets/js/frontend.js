(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["/js/frontend"],{

/***/ "./src/frontend/frontend.js":
/*!**********************************!*\
  !*** ./src/frontend/frontend.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("console.log('hello from front app js');//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zcmMvZnJvbnRlbmQvZnJvbnRlbmQuanM/YTdiMSJdLCJuYW1lcyI6WyJjb25zb2xlIiwibG9nIl0sIm1hcHBpbmdzIjoiQUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQWEseUJBQWIiLCJmaWxlIjoiLi9zcmMvZnJvbnRlbmQvZnJvbnRlbmQuanMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJjb25zb2xlLmxvZyggJ2hlbGxvIGZyb20gZnJvbnQgYXBwIGpzJyApOyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/frontend/frontend.js\n");

/***/ }),

/***/ 1:
/*!****************************************!*\
  !*** multi ./src/frontend/frontend.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\ASUS\Local Sites\wpdev\app\public\wp-content\plugins\wp-vue-kickstart\src\frontend\frontend.js */"./src/frontend/frontend.js");


/***/ })

},[[1,"/js/manifest"]]]);