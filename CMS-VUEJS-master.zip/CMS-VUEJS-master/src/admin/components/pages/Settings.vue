<template>
    <h2>Settings Page</h2>
</template>

<script>
export default {
    name: 'Settings'
}
</script>

<style>

</style>